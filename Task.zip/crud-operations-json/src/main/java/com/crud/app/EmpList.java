package com.crud.app;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
@Component
public class EmpList implements ApplicationListener<ApplicationReadyEvent> {
	
	@Autowired
	private Environment env;
	
	@Override
	  public void onApplicationEvent(final ApplicationReadyEvent event) {
		
		//System.out.println("path---->    "+env.getProperty("spring.activemq.broker-url"));
		 new File(env.getProperty("app.filedir")).mkdirs();
		 
		 System.out.println("dir creatd "+env.getProperty("app.filedir"));
			
	 
	    return;
	  }	

}
