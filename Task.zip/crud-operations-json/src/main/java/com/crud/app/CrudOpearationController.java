package com.crud.app;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/app")
public class CrudOpearationController {
	
	
	
	@Autowired
	private JsonService jsonService;
	
	@RequestMapping(method = RequestMethod.POST,value = "/create")
	public String createJson(@RequestBody Employee emp) {
		
		return jsonService.createEmp(emp);
	
		
	}
	
	@RequestMapping(method = RequestMethod.PUT,value = "/update/{id}")
	public String updateJson(@PathVariable String id,@RequestBody Employee emp) {
		
		return jsonService.updateEmp(emp, id);
		
	}
	
	
	@RequestMapping(method = RequestMethod.DELETE,value = "/delete/{id}")
	public String deleteJson(@PathVariable String id) {
		
		return jsonService.deleteEmp(id);
		
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "/getAll")
	public List<Employee> getAllJson() {
		
		return jsonService.listEmp();
		
		
	}
	@RequestMapping(method = RequestMethod.GET,value = "/sortAge")
	public String sortByAge() {
		
		return jsonService.sortbyAge();
		
		
	}


}
