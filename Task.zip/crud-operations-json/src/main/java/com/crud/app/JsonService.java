package com.crud.app;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class JsonService {
	
	@Autowired
	private Environment env;

	public String createEmp(Employee emp){
		
		ObjectMapper mapper = new ObjectMapper();
        List<Employee> listEmp=new ArrayList<>();
       
		try {
			
			List<Employee> listEmpDuplicate=listEmp();
			
			if(listEmpDuplicate!=null&&listEmpDuplicate.size()>=0) {
				Employee duplicateEmp= findEmp(emp.getId(), listEmpDuplicate);
				if(duplicateEmp!=null) {
					 return "duplicate";
				}else{
					listEmp.addAll(listEmpDuplicate);
					listEmp.add(emp);
					mapper.writeValue(new File(env.getProperty("app.filedir")+env.getProperty("app.filename")), listEmp);
	
				}
				
				
			}else {
				listEmp.add(emp);
				mapper.writeValue(new File(env.getProperty("app.filedir")+env.getProperty("app.filename")), listEmp);
			}
			
			
			
			//String jsonInString = mapper.writeValueAsString(emp);
			//System.out.println(jsonInString);
		}
		 catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return "created";
		
	}

	public List<Employee> listEmp() {
		ObjectMapper mapper = new ObjectMapper();

		try {

			// Convert JSON string from file to Object

			List<Employee> empList = Arrays
					.asList(mapper.readValue(new File(env.getProperty("app.filedir")+env.getProperty("app.filename")), Employee[].class));

			System.out.println(empList);
			return empList;

		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
		return null;
	}
	
	public Employee findEmp(String id,List<Employee> emplist) {
		
		
		for(Employee emp:emplist) {
			
			if(emp.getId().equals(id)) {
				return emp;
				
			}
			
		}
		
		return null;
		
	}
public String deleteEmp(String id) {
	ObjectMapper mapper = new ObjectMapper();
		
		List<Employee> emplist =new ArrayList<>();
		emplist.addAll(listEmp());
		for(Employee emp:emplist)
		{
		   System.out.println(""+emplist.indexOf(emp));	
			if(emp.getId().equals(id)) {
				emplist.remove(emplist.indexOf(emp));	
				
				break;
			}
			
		}
		try {
			mapper.writeValue(new File(env.getProperty("app.filedir")+env.getProperty("app.filename")), emplist);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("emp size"+emplist.size());
		return null;
		
	}
public String updateEmp(Employee em,String id) {
	ObjectMapper mapper = new ObjectMapper();
		
		List<Employee> emplist =new ArrayList<>();
		emplist.addAll(listEmp());
		for(Employee emp:emplist)
		{
		   System.out.println(""+emplist.indexOf(emp));	
			if(emp.getId().equals(id)) {
				emplist.remove(emplist.indexOf(emp));	
				
				break;
			}
			
		}
		// add emplyee object values to list
		emplist.add(em);
		
		// data write into json file
		try {
			mapper.writeValue(new File("/Users/kondalarao/json/emp.json"), emplist);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
		System.out.println("emp size"+emplist.size());
		return null;
		
	} 
public String sortbyAge() {
	ObjectMapper mapper = new ObjectMapper();
		
		List<Employee> emplist =new ArrayList<>();
		emplist.addAll(listEmp());
		
		 Collections.sort(emplist, new CustomCoparator());
		// data write into json file
		try {
			mapper.writeValue(new File(env.getProperty("app.filedir")+env.getProperty("app.filename")), emplist);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
		System.out.println("emp size"+emplist.size());
		return null;
		
	} 

  


	

}

