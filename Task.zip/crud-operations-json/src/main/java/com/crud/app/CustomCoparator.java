package com.crud.app;

import java.util.Comparator;

public class CustomCoparator implements Comparator<Employee> {

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		return o1.getAge().compareTo(o2.getAge());

	}
	
}
